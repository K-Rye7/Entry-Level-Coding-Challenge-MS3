package com.kryan20.csv; 

//got some of this code from https://www.mkyong.com/java/how-to-read-and-parse-csv-file-in-java/
//May or may not be too many comments in this. The more obvious explanations are for my own sanity than anyone else's 

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import java.sql.Connection;  
import java.sql.DatabaseMetaData;  
import java.sql.DriverManager;  
import java.sql.SQLException; 
import java.sql.Statement;
import java.text.ParseException;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

//This should make the database I need to access
class Make_db  {  
    public static void createNewDatabase(String fileName) {  
   
        String url = "jdbc:sqlite:C:/sqlite/" + fileName;
   
        try {  
            Connection conn = DriverManager.getConnection(url);  
            if (conn != null) {  
                DatabaseMetaData meta = conn.getMetaData();
            }  
   
        } catch (SQLException e) {  
            System.out.println(e.getMessage());  
        }  
    }  
  
    public static void main(String[] args) {  
        createNewDatabase("ELCC.db");  
    }  
}  
 //This should create the table I need... I think
class CreateTable {  
	   
    public static void createNewTable() {    
        String url = "jdbc:sqlite:C://sqlite/ELCC.db";  
          
        // creates the new table I got this from a source online. Don't know how it works, but it compiles. https://www.javatpoint.com/java-sqlite
        String sql = "CREATE TABLE IF NOT EXISTS ELCC"+ "A," + "B," + "C," + "D," + "E," + "F," + "G," + "H," + "I," + "J" + "\n" + ");";  
          
        try{  
            Connection conn = DriverManager.getConnection(url);  
            Statement stmt = conn.createStatement();  
            stmt.execute(sql);  
        } catch (SQLException e) {  
            System.out.println(e.getMessage());  
        }  
    }  
    public static void main(String[] args) {  
        createNewTable();  
    }  
   
}  


//Creates number counts to add to the log file at the end
class FileWideInts{
	int total = 0;
	int good = 0;
	int bad = 0; 
}

//Use this? for loading the CSV into the SQL https://www.viralpatel.net/java-load-csv-file-to-database/ 

public class CSVReader {
    public static void main(String[] args) throws FileNotFoundException, ParseException, SQLException, ClassNotFoundException{
    	
    	//Connection conn = null;
    	//Statement stmt = null;
    	
    	FileWideInts fwi = new FileWideInts();
        //Converts the csv to a string and makes it get rid of the commas
        String csvFile = "/Users/kryan20/csv/ELCC.csv";
        
        //parses the csv 
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            String line = "";
            
            // I got this from StackOverflow and changed it to make it work for me. I don't know why I needed to drop my previously established table
            //This should just overwrite the table created earlier and make it legible. 
            try {
            String url = "jdbc:sqlite:C://sqlite/ELCC.db";
            Class.forName("jdbc:sqlite:C:/sqlite/");
            Connection conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            String drop_sql = "DROP TABLE IF EXISTS ELCC";
            stmt.executeUpdate(drop_sql);
            String create_sql = "CREATE TABLE ELCC " +
                    "(A TEXT PIMARY KEY NOT NULL, " +
                    "B TEXT NOT NULL," + "C   TEXT   NOT NULL, " + "D   TEXT   NOT NULL, " + "E   TEXT   NOT NULL, " +
                    "F   TEXT   NOT NULL, " + "G   TEXT   NOT NULL, " + "H   TEXT   NOT NULL, " + "I   TEXT   NOT NULL, " +
                    "J   TEXT   NOT NULL )";
            
            stmt.executeUpdate(create_sql);
            File premFile = new File("ELCC.csv");
            Scanner scanner = new Scanner(premFile);
            scanner.useDelimiter(",");
        
            //
            
            //This creates a new csv. Can't get it to be named what they want though ...
            FileWriter csvWriter = new FileWriter("ELCC-bad.csv");
            //Creating string call info so in the for loop it can split it into an array of strings to append into the csv
            String colInfo = "A,B,C,D,E,F,G,H,I,J\n";

            for ( String ch : colInfo.split("") )
            {
                csvWriter.append(ch);
            }
            
            //This was just used for testing purposes 
            /*FileWriter csvWriter2 = new FileWriter("good.csv");
            //Creating string call info so in the for loop it can split it into an array of strings to append into the csv
            String colInfo2 = "A,B,C,D,E,F,G,H,I,J\n";

            for ( String ch2 : colInfo2.split("") )
            {
                csvWriter2.append(ch2);
            }*/
            
            //This is created to compare to f so I can add an entire line to the bad csv file easer
            int comp =0;
          //Loops through the csv until it ends
            while ((line = br.readLine()) != null) {
                //creates the name string for every column 
                String[] name = line.split(",");
                
                //These are strings that I think I need for adding to the SQLite database It was on the StackOverflow post I saw... 
                String sA = name[0];
                String sB = name[1];
                String sC = name[2];
                String sD = name[3];
                String sE = name[4];
                String sF = name[5];
                String sG = name[6];
                String sH = name[7];
                String sI = name[8];
                String sJ = name[9];
                //********************************************************* This just makes it easy to find 
                
                comp = fwi.bad;
              //iterate through the rows (stored in name) to see if there is an empty column or not
                for (int i = 0;  i < name.length; i++)
                {
                	//If the column in the row is blank this will make it skip the row and add to the bad row count
                    if (name[i] != null && name[i].isEmpty())
                    {
                    	//This line is for testing purposes
                        System.out.println("BAD ROW");
                        fwi.bad++;
                        break;
                    }
                }
                
                /*This is where I add the lines to the bad csv while also adding to the total line count for the log file.
                  It also continues through the while loop so I don't accidentally add bad lines to the database*/
                if (comp<fwi.bad) {
                	fwi.total++;
                    csvWriter.append(line);
                    csvWriter.append("\n");
                	continue;
                }
                //This was just for testing purposes 
                /*csvWriter2.append(line);
                csvWriter2.append("\n");
                */
                
                //This was just for me to be able to find this code easier is something went wrong
                //It should insert the data into the sql table column by column 
                //					*******************************
                String query = "INSERT INTO elcc VALUES (" +
                        "'" + sA + "', " +
                        "'" + sB + "', " +
                        "'" + sC + "', " +
                        "'" + sD + "', " +
                        "'" + sE + "', " +
                        "'" + sF + "', " +
                        "'" + sG + "', " +
                        "'" + sH + "', " +
                        "'" + sI + "', " +
                        "'" + sJ + "')";
                stmt.addBatch(query);
                //					********************************
                
                
                //This is for the log file at the end it counts the good files and the total lines
                fwi.good++;
                fwi.total++;
                
                //This was just for testing purposes 
                /*System.out.println("Name [" + name[0] + "," + name[1] + "]");*/
            }
            csvWriter.flush();
            csvWriter.close();
            
            //This was just for testing purposes
            /*csvWriter2.flush();
            csvWriter2.close();*/
            //
            
            //
            stmt.executeBatch();
            stmt.close();
            conn.close();
            scanner.close();
            //
            
            
            //This was just used for testing purposes
            /*System.out.println(fwi.bad); System.out.println(fwi.good); System.out.println(fwi.total);*/
            
        } catch ( Exception e ) {
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
    }
        }
        catch (IOException e) 
        {
            e.printStackTrace();
            //System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            //System.exit(0);;
        }
    }

}

//this should write the log file with all the numbers I counted earlier. I totally got most of this from somewhere else 
class WriteLogEntriesToLogFile {
    
    public static void main(String[] args) throws Exception {
    	FileWideInts fwi = new FileWideInts();
    	
        boolean append = true;
        FileHandler handler = new FileHandler("ELCC.log", append);
 
        Logger logger = Logger.getLogger("com.kryan20.csv");
        logger.addHandler(handler);
 
  logger.info("# of records received" + fwi.total);
  logger.info("# of records successful" + fwi.good);
  logger.info("# of records failed" + fwi.bad);
         
    }
 
}